#include "pch.h"
#include "cell.h"


cell::cell()
{
}


cell::~cell()
{
}

bool cell::getWall(int index)
{
	return walls[index];
}


void cell::setWall(int index, bool isWall)
{
	walls[index] = isWall;
}