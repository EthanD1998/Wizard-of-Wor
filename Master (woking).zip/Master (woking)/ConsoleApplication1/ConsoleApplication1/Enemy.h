#pragma once
#include "SFML/Graphics.hpp"
#include "Entity.h"
#include <iostream>

class Enemy : public Entity
{
	
public:

	Enemy(map*, std::vector<Entity*> *);
	~Enemy();
	void handleEvents() override;
	void newDirection();
	
	std::string type() override;
private:
	sf::Vector2i goalPos;
};

