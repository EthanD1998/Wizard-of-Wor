#include "pch.h"
#include "SFML/Graphics.hpp"
#include <iostream>
#include <cmath>
#include <time.h>

#include "DisplayState.h"
#include "StateManager.h"


int main()
{ 
	srand(time(NULL));
	
	StateManager control = StateManager();

	control.init();

}




