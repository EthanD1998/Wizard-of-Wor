#include "pch.h"
#include "Enemy.h"

/*
	Im not commenting this class yet because it still needs a ton  of work
	-Justin		
*/

Enemy::Enemy()
{
	color = sf::Color::Transparent;

	value = 0;
	
	facing = rand() % 4;
	current = getRelative();
	prev = current;
}

Enemy::~Enemy()
{
}

std::string Enemy::type()
{
	return "Enemy";
}


void Enemy::handleEvents()
{
	current = getRelative();
	if(animation.Alive)
		animation.updateTexture();
	
	if(invisible)
		columnOpacity();
		
	int t = clock.getElapsedTime().asMilliseconds();
	
	
	switch(facing)
	{
		case N:
			velocity.y = -1 * charMove;
			sprite.setRotation(90);
			break;
		case S:
			velocity.y = 1 * charMove;
			sprite.setRotation(270);
			break;
		case E:
			velocity.x = 1 * charMove;
			sprite.setScale(sf::Vector2f(charScale, -1 * charScale));
			sprite.setRotation(180);
			break;
		case W:
			velocity.x = -1 * charMove;
			sprite.setScale(charScale, charScale);
			sprite.setRotation(0);
			break;
		default:
			std::cout << "no direction " << facing << "\n";
	}

	if ((rand() % 500 == 0) && (teleport == true))
	{
		sprite.setPosition(sf::Vector2f((rand() % 11 + 2) * 60, (rand() % 6 + 1) * 60));
	}
	else
	{
		if ((sprite.getPosition() + sf::Vector2f(velocity.x * charMove * t, velocity.y * charMove * t)).y < 370)
			sprite.move(sf::Vector2f(velocity.x * charMove * t, velocity.y * charMove * t));
		else
			newDirection();
	}

	if (current != prev)
	{
		int randNum = rand() % 10;
		if (randNum < 6)
		{
			facing;
		}
		else if (randNum > 7)
		{
			if (facing > 0)
				facing = facing - 1;
			else
				facing = 3;
		}
		else
		{
			if (facing < 3)
				facing = facing + 1;
			else
				facing = 0;
		}
		velocity = sf::Vector2f(0, 0);
	}

	if(checkCollision())
	{
		sprite.move(sf::Vector2f(velocity.x * charMove * -1 * t, velocity.y * charMove * -1 * t));
		velocity = sf::Vector2f(0,0);
		newDirection();	
	}
	
	for(int i=0; i < entities->size(); i++)
	{
		if((entities->at(i)->type().find("Player") != std::string::npos) && sprite.getGlobalBounds().intersects(entities->at(i)->sprite.getGlobalBounds()))
		{
			entities->at(i)->Alive = false;
		}
	}
	
	if (rand() % 300 < shootChance && doesShoot) shoot();
	
	clock.restart().asSeconds();
	prev = current;
}

void Enemy::columnOpacity()
{
	if((player->getPosition().x == getPosition().x && player->Alive) || (player->getPosition().x == getPosition().x && player->Alive))
	{
		sprite.setColor(sf::Color(255,255,255,255));
	}
	else
	{
		sprite.setColor(sf::Color(255,255,255,0));
	}
}

void Enemy::newDirection()
{
	int temp = -1;
	while(temp == facing || temp > 3 || temp < 0)
	{
		temp = rand() % 4;
	}
	facing = temp;
}
