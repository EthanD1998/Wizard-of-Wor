#pragma once
#include <SFML/Graphics.hpp>
class walls
{
public:
	walls();
	walls(int, int, int);
	~walls();
	void setWall(int, int, int);
	sf::RectangleShape getWall();

private:
	sf::RectangleShape wall;
};

