#include "pch.h"
#include "walls.h"

//0 = top, 1 = right, 2 = bottom, 3 = left
walls::walls()
{
	wall.setSize(sf::Vector2f(40, 5));
	wall.setOrigin(sf::Vector2f(wall.getSize().x / 2, wall.getSize().x / 2));
	wall.setFillColor(sf::Color::Blue);

}

walls::walls(int side, int x, int y)
{
	wall.setSize(sf::Vector2f(40, 5));
	wall.setOrigin(sf::Vector2f(wall.getSize().x / 2, wall.getSize().x / 2));
	wall.setFillColor(sf::Color::Blue);
	wall.setRotation(side * 90);
	wall.setPosition(sf::Vector2f(wall.getSize().x * x + 45, wall.getSize().x * y + 45));
}

walls::~walls()
{

}

void walls::setWall(int side, int x, int y)
{
	wall.setRotation(side * 90);
	wall.setPosition(sf::Vector2f(wall.getSize().x * x, wall.getSize().x * y));
	return;
}

sf::RectangleShape walls::getWall()
{
	return wall;
}