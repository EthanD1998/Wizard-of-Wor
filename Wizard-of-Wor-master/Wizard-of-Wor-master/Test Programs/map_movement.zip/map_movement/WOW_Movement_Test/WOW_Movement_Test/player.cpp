#include "pch.h"
#include "player.h"


player::player(int scale, int playerNum, double speed)
{
	user.setPosition(45 * scale, 45 * scale);
	if(!userSprite.loadFromFile("Sprites/Worrior1.png"))
	{	}
	user.setTexture(userSprite);
	user.setScale(sf::Vector2f(scale,scale));
	playerSpeed = speed;
}


player::~player()
{
}

void player::move(map *level)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		user.setPosition(sf::Vector2f(user.getPosition().x, user.getPosition().y - playerSpeed));

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		user.setPosition(sf::Vector2f(user.getPosition().x, user.getPosition().y + playerSpeed));

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		user.setPosition(sf::Vector2f(user.getPosition().x - playerSpeed, user.getPosition().y));

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		user.setPosition(sf::Vector2f(user.getPosition().x + playerSpeed, user.getPosition().y));
}

sf::Sprite player::getUser()
{
	return user;
}

Cell * player::getMapPos(map *level)
{
	return nullptr;
}


