#pragma once
#include "map.h"
#include <SFML/Graphics.hpp>
class player
{
public:
	player(int, int,double);
	~player();
	void move(map*);
	sf::Sprite getUser();
private:
	sf::Sprite user;
	sf::Texture userSprite;
	double playerSpeed;
	Cell* getMapPos(map*);
};

