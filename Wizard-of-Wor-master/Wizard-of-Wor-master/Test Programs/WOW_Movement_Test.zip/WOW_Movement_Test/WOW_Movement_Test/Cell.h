#pragma once
#include "walls.h"
#include <vector>
class Cell
{
public:
	Cell();
	~Cell();
	void set(bool[4], int,int);
	std::vector<walls> getWalls();
	bool hasWall();
private:
	bool isWall[4];
	std::vector<walls> wall;
};

