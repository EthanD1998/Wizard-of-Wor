#pragma once
class cell
{
public:
	cell();
	~cell();
	bool getWall(int);
	void setWall(int, bool);
private:
	bool walls[4] = { false,false,false,false };
};

