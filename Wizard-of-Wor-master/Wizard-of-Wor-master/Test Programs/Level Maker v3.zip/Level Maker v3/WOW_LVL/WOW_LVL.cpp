#include "pch.h"
#include <iostream>
#include <SFML/Graphics.hpp>
#include "cell.h"
#include <vector>
#include <fstream>

void writeCSV(std::vector<std::vector<cell>>);
void printMap(std::vector<std::vector<cell>>, sf::RenderWindow&);
void loadMap(std::vector<std::vector<cell>> *);
std::vector<int> setProperties();

	std::vector<int> properties;

int main()
{
	sf::RenderWindow window(sf::VideoMode(800, 600), "Wizard of Wor LVL");
	sf::Vector2i mPos(sf::Vector2i(0, 0));
	sf::RectangleShape select(sf::Vector2f(40, 40));
	std::vector<std::vector<cell>> map;
	sf::Vector2i cellSelect(sf::Vector2i(666, 0));


	map.resize(13);
	for (int i = 0; i < 13; i++)
	{
		map.at(i).resize(7);
	}

	select.setFillColor(sf::Color(0, 0, 0, 0));
	select.setOutlineColor(sf::Color(0, 255, 0, 200));
	select.setOutlineThickness(3);

	properties = setProperties();
	
	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			
				if (event.type == sf::Event::MouseButtonPressed)
				{
					mPos = sf::Mouse().getPosition(window);
				}
			if (event.type == sf::Event::KeyPressed)
			{
					if (cellSelect.x < 13 && cellSelect.y < 7)
					{
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
							map.at(cellSelect.x).at(cellSelect.y).setWall(0, !map.at(cellSelect.x).at(cellSelect.y).getWall(0));
						
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
							map.at(cellSelect.x).at(cellSelect.y).setWall(1, !map.at(cellSelect.x).at(cellSelect.y).getWall(1));
						
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
							map.at(cellSelect.x).at(cellSelect.y).setWall(2, !map.at(cellSelect.x).at(cellSelect.y).getWall(2));
						
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
							map.at(cellSelect.x).at(cellSelect.y).setWall(3, !map.at(cellSelect.x).at(cellSelect.y).getWall(3));
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
						{
							writeCSV(map);
						}
						if (sf::Keyboard::isKeyPressed(sf::Keyboard::L))
						{
							loadMap(&map);
						}
						

					}
			}
		}

		window.clear();

		printMap(map, window);
		if (mPos.x > 20 && mPos.x < 540)
		{
			if (mPos.y > 20 && mPos.y < 300)
			{
				cellSelect = sf::Vector2i((mPos.x - 20) / 40, (mPos.y - 20) / 40);
				select.setPosition(sf::Vector2f(40 * static_cast<int>((mPos.x - 20) / 40) + 20, 40 * static_cast<int>((mPos.y - 20) / 40) + 20));
				window.draw(select);
			}
		}
		window.display();

	}

	return 0;
}

std::vector<int> setProperties()
{
	std::vector<int> r;
	r.resize(4);
	int t;

	
	std::cout << "Amount of Burwor\n";
	std::cin >> t;
	r.at(0) = t;
	
	std::cout << "Amount of Garwor\n";
	std::cin >> t;
	r.at(1) = t;
	
	std::cout << "Amount of Burwor\n";
	std::cin >> t;
	r.at(2) = t;
	
	std::cout << "Color (1-4)\n";
	std::cin >> t;
	r.at(3) = t;
	
	return r;
}

void loadMap(std::vector<std::vector<cell>>* map)
{
	std::string t;


	std::cout << "Enter the full path of the file to load\n";
	std::cin >> t;
	std::ifstream file(t);
	std::string value;

		while (file.good())
		{
			for (int i = 0; i < 13; i++)
			{
				for (int j = 0; j < 7; j++)
				{
					for (int k = 0; k < 4; k++)
					{
						getline(file, value, ',');
						if (value.find("1") != std::string::npos)
						{
							map->at(i).at(j).setWall(k, true);
						}
					}
				}
			}
			
		}

		std::cout << "Loaded Map" << std::endl;

}



void writeCSV(std::vector<std::vector<cell>> map)
{
	std::ofstream myfile;
	std::string t;

	std::cout << "File path to save to: ";
	std::cin >> t;


	myfile.open(t);

	for(int i=0; i < 4; i++)
	{
		myfile << properties.at(i);
		myfile << ",";
	}
	
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			for (int k = 0; k < 4; k++)
			{
				myfile << map.at(i).at(j).getWall(k);
				myfile << ",";
			}
		}
	}
	std::cout << "Wrote level to " << t << std::endl;
	myfile.close();
}

void printMap(std::vector<std::vector<cell>> map, sf::RenderWindow &window)
{
	sf::RectangleShape wall(sf::Vector2f(40, 5));
	sf::RectangleShape wall2(sf::Vector2f(40, 5));
	wall.setFillColor(sf::Color::Blue);
	wall2.setFillColor(sf::Color(100, 100, 100, 200));
	wall.setOrigin(20, 20);
	wall2.setOrigin(20, 20);
	for (int i = 0; i < 13; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			for (int k = 0; k < 4; k++)
			{
				if (map.at(i).at(j).getWall(k))
				{
					wall.setPosition(40 * i + 40, 40 * j + 40);
					wall.setRotation(90 * k);
					window.draw(wall);
				}
				else
				{
					wall2.setPosition(40 * i + 40, 40 * j + 40);
					wall2.setRotation(90 * k);
					window.draw(wall2);
				}
			}
		}
	}

}
