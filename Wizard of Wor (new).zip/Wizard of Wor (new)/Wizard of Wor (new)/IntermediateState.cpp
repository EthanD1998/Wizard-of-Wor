#include "pch.h"
#include "IntermediateState.h"


IntermediateState::IntermediateState(int index, int nextLevel, int pCount, std::vector<int> playerProp)
{
	gameIndex = index;
	nextGameLevel = nextLevel;
	gamePCount = pCount;
	gamePlayerProp = playerProp;

	font.loadFromFile("Fonts/AlienEncounters.ttf");

	second.setFont(font);
	text.setFont(font);

	text.setString("GET READY");
	text.setCharacterSize(100);
	text.setFillColor(sf::Color::Yellow);
	second.setString("GO");
	second.setCharacterSize(100);
	second.setFillColor(sf::Color::Yellow);


	sf::FloatRect textRect = text.getLocalBounds();
	text.setOrigin(textRect.left + textRect.width / 2.0f, textRect.top + textRect.height / 2.0f);
	text.setPosition(sf::Vector2f(420, 200));
	textRect = second.getLocalBounds();
	second.setOrigin(textRect.left + textRect.width / 2.0f, textRect.top + textRect.height / 2.0f);
	second.setPosition(sf::Vector2f(425, 400));
}


IntermediateState::~IntermediateState()
{

}


void IntermediateState::updateEvents()
{

}


DisplayState* IntermediateState::nextState()
{
	return new Game(gameIndex, nextGameLevel, gamePCount, gamePlayerProp);
}


void IntermediateState::draw(sf::RenderWindow *target)
{
	int temp = round(clock.getElapsedTime().asSeconds());
	if (temp > sec)
	{
		sec = temp;
	}
	target->draw(text);
	if (sec > 1)
		target->draw(second);
	if (sec > 2)
	{
		hasFocus = false;
		exists = false;
	}
}