#pragma once
#include "DisplayState.h"
#include "Game.h"
class IntermediateState : public DisplayState
{
public:
	IntermediateState(int, int, int, std::vector<int>);
	~IntermediateState();

	int gameIndex, nextGameLevel, gamePCount;
	std::vector<int> gamePlayerProp;

	sf::Text text, second;

	sf::Font font;

	void updateEvents() override;

	DisplayState* nextState() override;

	void draw(sf::RenderWindow*) override;
};

